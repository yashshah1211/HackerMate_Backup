// Explicit opt-in; GET only, no cookies, credentials, RPC calls or mutations.
const assert=require('node:assert/strict');
const BASE='/partners/hustle-carnival/phase-2',API='/api/partners/hustle-carnival/phase-2';
async function checkOff(origin,request=fetch,onResponse=()=>{}){
  const url=new URL(origin);assert.equal(url.origin,origin);assert.equal(url.protocol,'https:');
  const results=[];
  for(const endpoint of [BASE,BASE+'/invite',BASE+'/organizer',...['session','clear-context','claim','respond','organizer','export','columns','import','activate','invite','revoke'].map(a=>API+'/'+a)]){
    const r=await request(origin+endpoint,{redirect:'manual',headers:{'Cache-Control':'no-cache'},signal:AbortSignal.timeout(20000)});
    onResponse({endpoint,status:r.status,cacheControl:r.headers.get('cache-control'),referrerPolicy:r.headers.get('referrer-policy'),setsCookie:r.headers.has('set-cookie'),location:r.headers.get('location')});
    assert.equal(r.status,endpoint.startsWith(API)?503:200,endpoint);
    assert.match(r.headers.get('cache-control')||'',/no-store/);assert.equal(r.headers.get('referrer-policy'),'no-referrer');
    assert.equal(r.headers.get('set-cookie'),null,'No session should be created by disabled routes');
    assert.match(await r.text(),/not available yet/i);results.push({endpoint,status:r.status});
  }
  for(const endpoint of ['/partners/hustle-carnival','/partners/hustle-carnival/workshops','/login']){
    const r=await request(origin+endpoint,{redirect:'manual',signal:AbortSignal.timeout(20000)});onResponse({endpoint,status:r.status,location:r.headers.get('location')});assert.equal(r.status,200,endpoint);results.push({endpoint,status:200});
  }
  return results;
}
module.exports={checkOff};
if(require.main===module){
  if(process.argv[2]!=='--authorized'||!process.argv[3]){console.error('No request made. After approval: node off-smoke.cjs --authorized https://EXACT_APPROVED_HOST');process.exitCode=1;}
  else {
    const responses=[];
    checkOff(process.argv[3],fetch,r=>responses.push(r)).then(r=>console.log(JSON.stringify({origin:process.argv[3],checks:r.length,pass:true,responses,serverDatabaseSilence:'Requires separate hosting/log or instrumented evidence; HTTP alone cannot prove it'}))).catch(error=>{console.error(JSON.stringify({origin:process.argv[3],pass:false,responses,outcome:responses.length?'HTTP_OR_HEADER_CHECK_FAILED':'NO_APPLICATION_HTTP_RESPONSE',errorCode:error.code||error.cause?.code||error.name}));process.exitCode=1});
  }
}
