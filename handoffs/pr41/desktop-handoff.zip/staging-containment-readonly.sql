-- Desktop only, on VERIFIED qusshzpkvwzfhdcmsosp connection. No raw secrets/PII output.
-- Read-only evidence; this file does not itself establish connection identity.
BEGIN TRANSACTION READ ONLY;
SET LOCAL statement_timeout='10s';
SELECT current_database(),current_user,current_setting('transaction_read_only') AS must_be_on,
 current_setting('supabase.project_ref',true) AS project_ref_if_available;
-- Both true required for the known notification trigger's early-return containment.
SELECT NOT EXISTS(SELECT 1 FROM public.app_settings WHERE key='site_url' AND coalesce(btrim(value),'')<>'') AS destination_absent,
 NOT EXISTS(SELECT 1 FROM public.app_secrets WHERE key='webhook_secret' AND coalesce(btrim(value),'')<>'') AS notification_secret_absent;
SELECT count(*) AS must_be_zero FROM net.http_request_queue;
-- Compare function source privately with the existing reviewed missing-config early return.
-- Return fingerprint and metadata, never secret values or the HTTP queue's bodies/headers.
SELECT p.oid::regprocedure AS signature,pg_get_userbyid(p.proowner) AS owner,
 md5(pg_get_functiondef(p.oid)) AS definition_fingerprint,p.prosecdef,p.proconfig
FROM pg_proc p WHERE p.oid=to_regprocedure('public.handle_notification_insert_webhook()');
SELECT t.tgrelid::regclass AS relation,t.tgname,t.tgenabled,p.oid::regprocedure AS function
FROM pg_trigger t JOIN pg_proc p ON p.oid=t.tgfoid
WHERE NOT t.tgisinternal AND (p.proname='handle_notification_insert_webhook' OR pg_get_functiondef(p.oid) ~ 'net[.]http_(post|get)');
-- Other outbound-capable functions need private review before writes, not blanket dismissal.
SELECT n.nspname,p.proname,md5(pg_get_functiondef(p.oid)) AS definition_fingerprint
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE p.prokind='f' AND n.nspname NOT IN ('pg_catalog','information_schema','net')
AND pg_get_functiondef(p.oid) ~ 'net[.]http_(post|get)';
-- Installation inventory only. Missing prerequisites need scoped STAGING setup, never full db push.
SELECT to_regclass('public.hackathons') IS NOT NULL AS event_table,
 to_regclass('public.event_organizers') IS NOT NULL AS organizer_foundation,
 to_regprocedure('public.hustle_phase2_has_active_session()') IS NOT NULL AS auth_guards,
 to_regclass('public.hustle_phase2_participants') IS NOT NULL AS participant_table;
SELECT version,name FROM supabase_migrations.schema_migrations
WHERE version IN ('202610060002','20261018082156','20261018174144','20261020055415') ORDER BY version;
SELECT p.oid::regprocedure AS signature,pg_get_userbyid(p.proowner) AS owner,p.prosecdef,p.proconfig,p.proacl
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname='public' AND p.proname LIKE 'hustle_phase2_%' ORDER BY p.proname;
ROLLBACK;
