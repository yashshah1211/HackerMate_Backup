PR #41 immediate launch preparation — LOCAL, NOT DEPLOYED

Frozen application: afad293158f5db224dbf3978ffa6271d8f8a7f77. No production/staging SQL, accounts, resources, settings, deployments or data were changed. Desktop owns r7; this packet does not contain or alter migration SQL.

Ready artifacts

- prepare-test-artifact.cjs: offline two-file overlay generator. Only the enabled() gate and its request-origin arguments change. Source and pages SHA256 are checked against frozen PR41. Original production source constant stays false. SQL, identity checks, CSRF, role checks, grants and RPC bodies remain unchanged.
- target.example.json: no credentials, disabled placeholders. Actual nonproduction ref/origin must be independently established before generating the deployable overlay.
- off-smoke.cjs: opt-in GET-only unauthenticated deployed HTTP smoke. No SDK, credentials or mutation requests. HTTP results alone cannot prove absence of server-side database calls.
- hosted-oauth-acceptance.cjs: opt-in headed browser, human-controlled provider login; captures session only in memory, then exercises approved synthetic claims/RPCs. It never saves cookies, JWTs, traces, screenshots or private output. It does not provision schema/accounts/roster. It is a focused executable subset, not automatic sign-off of every journey below.
- test-artifact.cjs and test-runners.cjs: offline safety/guard tests.

Known deployment evidence, checked through GitHub

- Current main source is 97bb87d935d4b9e5efa7d592e4e9ea715f61bed1.
- Its successful Vercel status links deployment 5pbUDrwwQb1ZLaH3vqLA1zUUaTvw:
  https://vercel.com/yashshah1211s-projects/hacker-mate-backup/5pbUDrwwQb1ZLaH3vqLA1zUUaTvw
- PR41 Preview: CyF8sGaXGangLkuqkrPEAkTk6KqM:
  https://vercel.com/yashshah1211s-projects/hacker-mate-backup/CyF8sGaXGangLkuqkrPEAkTk6KqM
- These status links do not prove the CURRENT production alias, rollback eligibility or settings. Vercel console pages are inaccessible through this session's tools; Supabase dashboard does not expose authenticated project metadata. No Vercel/Supabase account connector, ready outbound identity or runtime credential is attached. Do not call the candidate current production until Yash confirms the alias.

Exact Yash checks (read-only, redact secrets)

1. Vercel project overview https://vercel.com/yashshah1211s-projects/hacker-mate-backup : open the CURRENT Production deployment. Record deployment ID, Ready status, Source Git SHA and assigned hackermate.in/www domains. Compare to 5pbUDrwwQb1ZLaH3vqLA1zUUaTvw/97bb87d; if different, record the actual values. Confirm previous deployment can be promoted/rolled back by the assigned operator.
2. Vercel Settings -> Environments -> Production: inspect branch tracking/production branch. Settings -> Git: connected repo, Git deployment enablement and any ignored-build behavior. Confirm whether main merge automatically creates/promotes production; do not merge to discover it. Linked GitHub Vercel statuses prove integration exists, not its current production settings.
3. Vercel Settings -> Environment Variables:
   https://vercel.com/yashshah1211s-projects/hacker-mate-backup/settings/environment-variables
   Inspect Production and Preview scopes plus branch overrides/shared variables. Production: HUSTLE_PHASE2_ENABLED=false; HUSTLE_PHASE2_RELEASE_APPROVED=false; HUSTLE_PHASE2_LOCAL_FIXTURE=false or absent; HUSTLE_PHASE2_HOSTED_TEST absent. ACCOUNT_ONBOARDING_RELEASE_APPROVED is source-only, not an env variable. NODE_ENV/VERCEL_ENV remain platform-managed. NEXT_PUBLIC_SUPABASE_URL must be exact https://rhryjrbebfrrfhtyyzbs.supabase.co; NEXT_PUBLIC_SITE_URL the real HTTPS site. Confirm NEXT_PUBLIC_SUPABASE_ANON_KEY and server-only SUPABASE_SERVICE_ROLE_KEY privately belong to that project; report match/mismatch, never values. Existing settings must not be changed under this task. NEXT_PUBLIC values are build-time inputs: inspecting a dashboard edit alone does not verify a deployed bundle.
4. Supabase https://supabase.com/dashboard/projects : open staging-named project -> Settings -> General, record actual project ref and ownership. It must differ from rhryjrbebfrrfhtyyzbs. Settings -> API Keys / Connect: privately match URL and anon/service keys to that project, then compare to Vercel test branch's build and server settings. Observe browser Auth/Data API origins after approved login. No key strings in chat.
5. Supabase staging Auth -> Users and project integrations: an authorized owner must establish synthetic-only contents and absence of production account/data replication. Do not export users. Confirm no production SMTP/webhook/email/cron integration. No SQL inspection is authorized here; reuse safe owner evidence or separately authorize the necessary inspection/setup.
6. Supabase organization -> Billing/Subscription and Usage: current plan, available compute allowance/project quota and whether the existing stage incurs incremental cost; no new project under paid org assumed free. Free entitlement is two active projects, subject to owner/admin quotas. Vercel team -> Settings -> Billing/Usage: current plan, remaining build/function allowances, and Hobby noncommercial eligibility if applicable. No trials/upgrades or credit-card steps. No verified zero-cost hosted pair is claimed until those checks pass.
7. Staging Auth -> Sign In / Providers -> Google and GitHub, and Auth -> URL Configuration: enabled provider clients, callback project and exact test frontend allowlist. Google Auth Platform -> Clients and Audience/Test Users; GitHub Settings -> Developer settings -> OAuth Apps: inspect dedicated test clients/callbacks and controlled tester eligibility. Production client changes are not authorized. Provider setup changes/test identities require separate approval.

Minimum test-only configuration, after approval

- Use an existing isolated project if all checks pass. One stable Vercel branch Preview origin, not a production alias. No production keys, production env inheritance, real roster or mirrored Auth accounts.
- Generator requires a literal nonproduction 20-letter ref and exact HTTPS *.vercel.app origin. Test runtime requires NODE_ENV=production, VERCEL_ENV=preview, actual request origin and NEXT_PUBLIC_SITE_URL matching the frozen origin, and platform VERCEL_URL or VERCEL_BRANCH_URL matching it. It fails in production scope even if test flags are copied there.
- Preview branch-only HUSTLE_PHASE2_HOSTED_TEST=true, HUSTLE_PHASE2_ENABLED=true, HUSTLE_PHASE2_RELEASE_APPROVED=false, HUSTLE_PHASE2_LOCAL_FIXTURE=false. TEST project URL and TEST keys only. Never set these project-wide. Source production gate remains false.
- Test Supabase Site URL = exact frontend origin. Additional redirect URL = exact frontend /auth/callback (configure next query compatibility narrowly). Google/GitHub provider callback = https://TEST_REF.supabase.co/auth/v1/callback. Separate test clients and least-required scopes; Google test users allow only approved testers. Match frontend origin throughout to preserve PKCE and invitation cookies.
- No production SQL edits. Approved schema-compatible test fixture setup is separate. For successful attendance TODAY, the real clock is before Oct23: separately approve an isolated test-clock fixture, following existing disposable fixture approach. Never change production clocks/deadlines or ship a substituted clock. Without that fixture, hosted tests can prove before-window denial, not successful attendance today.
- Prepare three owned app identities (leader/member/unrelated), with real controlled Google/GitHub identities and fresh synthetic pair(s). Onboarding may create test app users, so approve that explicitly. Dedicated tests may need additional fresh pair(s) for opposing decisions and provider runs.

Offline commands (safe now, no connections)

    node /workspace/work/pr41-launch-readiness/test-artifact.cjs
    node /workspace/work/pr41-launch-readiness/test-runners.cjs

Once the target is confirmed, copy target.example.json to a private target.json with the exact ref/origin. Generate an uncommitted overlay for review (not a full deployable repo):

    node /workspace/work/pr41-launch-readiness/prepare-test-artifact.cjs /workspace/work/audit-pr41 /PRIVATE/target.json /NEW/overlay

Review only the two changed modules and manifest; apply solely to a separate test checkout, retain production source/SQL unchanged and run its normal locked build. Do not publish that branch until Preview deployment is authorized. No output directory is overwritten.

After separate OFF deployment/probe approval

    node /workspace/work/pr41-launch-readiness/off-smoke.cjs --authorized https://EXACT_APPROVED_PRODUCTION_HOST

Also verify exact READY SHA/OFF envs through Vercel and server database silence using existing approved instrumentation. No test-only diagnostic endpoint is added. Smoke existing login/onboarding/dashboard/team/admin/organizer/public portal/workshops through an approved account plan. This runner deliberately does not reuse real accounts.

After isolated infrastructure/test approval

Copy scenario.example.json to a restricted private scenario file. Attest all four booleans only after evidence. Put only synthetic invitation material there; use a private directory. Supply TEST keys through the approved local secret mechanism as PR41_TEST_ANON_KEY and optional PR41_TEST_SERVICE_KEY. Do not place keys on command lines. JWT keys are checked for matching project ref; opaque keys require the dashboard alignment attestation. Keys remain in memory, never output. Existing Playwright/Chromium must be available; no package install or browser download is performed.

    node /workspace/work/pr41-launch-readiness/hosted-oauth-acceptance.cjs --authorized /PRIVATE/google-leader.json

Repeat with provider github and separate approved fresh fixture. Human completes only the controlled provider login and onboarding, then presses Enter. This script MAY claim and respond in the isolated target, so do not invoke it before setup/test authorization.

Acceptance cases (all required, redacted outcomes only)

1. Both providers: fresh account and existing account; invitation fragment removed before exchange; actual provider redirect; fixed token-free application return; incomplete onboarding continuation; HTTPS root-path HttpOnly/Secure/SameSite=Lax context retained. Correct distinct UUID/email roster claims, no email/UUID leakage to unrelated users.
2. Fresh pair leader before member: claim partial, confirm via BROWSER during isolated open clock; repeated same response stable; opposite response rejected. Member then signs in independently, claims without invitation and completes account count without changing attendance. Repeat decline on fresh pair. The runner checks real OAuth/SSR and direct RPC behavior; browser button behavior is an additional manual case.
3. Member with copied synthetic leader invitation context and unrelated user: no attendance through routes/direct PostgREST. Anonymous/service credentials cannot restore legacy attendance. Runner accepts effective-denial HTTP statuses; exact EXECUTE ACL proof is the approved postflight metadata, not status alone.
4. Expired/tampered/wrong-team/revoked invitations, wrong-account recovery, missing/null/cross-site Origin denial, no-referrer unchanged. Clear-context succeeds at the fixed origin. Browser refresh/rotation retains SSR cookies. Use only isolated test sessions to test logout/revocation/expiry; no production account/session manipulation.
5. Unverified/anonymous/banned/missing profile and incomplete onboarding deny using approved isolated fixtures. Concurrent bindings/responses have one binding/winner and expected audit. No unauthorized export/table/internal-helper access.
6. Before/open/closing-after-lock attendance boundaries and member claim after closure. A test-only clock requires separate approval; production definitions remain unchanged. Today without it, record successful attendance as BLOCKED, not passed.
7. Chromium and WebKit/mobile HTTPS recovery/cookie checks; no secret-bearing URLs after exchange, no private values in logs/replay/screenshots/HARs. Clean up approved synthetic resources and retain only safe evidence.

Rollback and launch order

Record CURRENT production rollback ID before approval. Old application code cannot regain token-only authority if installed SQL bodies/ACLs remain as postflight proved; never roll back the DB. Source-OFF rollout stops new app-route work, not direct RPCs or already-running requests. No code-only rollback promises data recovery.

Today: finish independent artifacts/OAuth target approval in parallel with Desktop r7. After production postflight and merge/deploy approval, land PR41 OFF, prove actual artifact and regressions, record it as preferred OFF rollback. Complete isolated OAuth acceptance. Separately approve the minimal production source-gate release change and both runtime switches if enabling the empty portal today; empty shortlist remains no participant authority. This artifact preparation does not authorize that change/deployment.

Oct22 20:00 IST: receive official approved file privately -> validate IDs/emails/solo-pair roles/counts -> freeze hash/mapping -> fresh live preview/receipt -> separately approved inactive UI import -> readback/reconcile -> separately approved exact-batch activation -> separately approved leader invitations. Oct23 10:00 inclusive to 23:00 exclusive IST: authenticated bound leaders only; monitor totals/errors, preserve member signup after attendance closes. No real roster import, activation or sending is authorized here.
