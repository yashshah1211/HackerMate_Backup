// Offline only. Produces reviewable files; never edits the input checkout or deploys.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const PROD = 'rhryjrbebfrrfhtyyzbs';
function target(input) {
  if (!/^[a-z]{20}$/.test(input.projectRef || '') || input.projectRef === PROD) throw Error('Explicit nonproduction project ref required');
  const u = new URL(input.origin);
  if (u.protocol !== 'https:' || u.origin !== input.origin || u.username || u.password || u.port || !u.hostname.endsWith('.vercel.app')) throw Error('Exact HTTPS Vercel Preview origin required');
  if (/hackermate\.in$/.test(u.hostname)) throw Error('Production origin forbidden');
  return input;
}
function transform(server, pages, config) {
  const t = target(config);
  const signature = 'export function enabled(): boolean {';
  if (server.split(signature).length !== 2 || !pages.includes('if (!enabled())')) throw Error('Unexpected source layout');
  const testGate = `export function enabled(requestOrigin?: string): boolean {
  // TEST ARTIFACT ONLY: exact target frozen at preparation time; never merge to main.
  if (process.env.HUSTLE_PHASE2_HOSTED_TEST === "true") {
    const testOrigin = ${JSON.stringify(t.origin)};
    return process.env.NODE_ENV === "production" && process.env.VERCEL_ENV === "preview"
      && requestOrigin === testOrigin && process.env.NEXT_PUBLIC_SITE_URL === testOrigin
      && [process.env.VERCEL_URL, process.env.VERCEL_BRANCH_URL].some(host => host && "https://" + host === testOrigin)
      && process.env.HUSTLE_PHASE2_ENABLED === "true"
      && process.env.HUSTLE_PHASE2_RELEASE_APPROVED === "false"
      && process.env.HUSTLE_PHASE2_LOCAL_FIXTURE !== "true"
      && process.env.NEXT_PUBLIC_SUPABASE_URL === ${JSON.stringify('https://' + t.projectRef + '.supabase.co')}
      && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim()
      && !!process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();
  }`;
  const s = server.replace(signature, testGate).replace('if (!enabled())', 'if (!enabled(req.nextUrl.origin))');
  const p = pages.replace('if (!enabled())', 'if (!enabled(req.nextUrl.origin))');
  if (!s.includes('const ACCOUNT_ONBOARDING_RELEASE_APPROVED = false;')) throw Error('Production source gate changed');
  return { server: s, pages: p };
}
function main() {
  const [repo, configPath, out] = process.argv.slice(2);
  if (!repo || !configPath || !out || fs.existsSync(out)) throw Error('Usage: node prepare-test-artifact.cjs <frozen-checkout> <target.json> <NEW-output-dir>');
  const file = p => fs.readFileSync(path.join(repo, p), 'utf8').replace(/\r\n/g, '\n');
  const server = file('src/lib/hustle-phase2/server.ts'), pages = file('src/lib/hustle-phase2/pages.ts');
  const sha = s => crypto.createHash('sha256').update(s).digest('hex');
  if (sha(server) !== '23c1fbf76ca2771f800fac4846a90284b196bfac592f4e6fffadb4adfc5fec43') throw Error('Input is not frozen PR41 server');
  if (sha(pages) !== '69a3a678bd33b6a9bf5f65ed65519f431c590f51893918ea94d2296dce647c88') throw Error('Input is not frozen PR41 pages');
  const config = target(JSON.parse(fs.readFileSync(configPath, 'utf8'))), built = transform(server, pages, config);
  const manifest = { base: 'afad293158f5db224dbf3978ffa6271d8f8a7f77', target: config,
    input: { server: sha(server), pages: sha(pages) }, output: { server: sha(built.server), pages: sha(built.pages) },
    deploymentAuthorized: false, productionSourceGate: false };
  fs.mkdirSync(path.join(out, 'src/lib/hustle-phase2'), {recursive:true});
  fs.writeFileSync(path.join(out, 'src/lib/hustle-phase2/server.ts'), built.server, {flag:'wx'});
  fs.writeFileSync(path.join(out, 'src/lib/hustle-phase2/pages.ts'), built.pages, {flag:'wx'});
  fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(manifest,null,2)+'\n', {flag:'wx'});
  fs.writeFileSync(path.join(out, 'preview.env.example'), `# Preview scope ONLY, restricted to approved test branch\nHUSTLE_PHASE2_HOSTED_TEST=true\nHUSTLE_PHASE2_ENABLED=true\nHUSTLE_PHASE2_RELEASE_APPROVED=false\nHUSTLE_PHASE2_LOCAL_FIXTURE=false\nNEXT_PUBLIC_SITE_URL=${config.origin}\nNEXT_PUBLIC_SUPABASE_URL=https://${config.projectRef}.supabase.co\n# Set only TEST-project keys through secure Vercel configuration. Never copy production secrets.\n`, {flag:'wx'});
  console.log('Prepared two-file TEST-ONLY overlay and manifest. No checkout/settings changed.');
}
module.exports = {target, transform};
if (require.main === module) { try {main()} catch {console.error('Preparation refused: verify arguments, frozen source, target and new output directory.');process.exitCode=1;} }
