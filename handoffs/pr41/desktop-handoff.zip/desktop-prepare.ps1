[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Repo,
  [Parameter(Mandatory=$true)][string]$Worktree
)
$ErrorActionPreference='Stop'
function Run-Checked([string]$Exe,[string[]]$Arguments) {
  & $Exe @Arguments
  if ($LASTEXITCODE -ne 0) { throw "$Exe failed; stop before connected work." }
}
$packet=$PSScriptRoot
$merge='64e72795200e9eb9c2df1e91939a1c1ef381c5a8'
if (Test-Path $Worktree) { throw 'Use a NEW worktree path; nothing will be overwritten.' }
Run-Checked 'git' @('-C',$Repo,'cat-file','-e',"$merge`^{commit}")
Run-Checked 'git' @('-C',$Repo,'worktree','add','--detach',$Worktree,$merge)
$overlay=Join-Path $Worktree 'work\oauth-overlay'
Run-Checked 'node' @((Join-Path $packet 'prepare-test-artifact.cjs'),$Worktree,(Join-Path $packet 'target.staging.proposed.json'),$overlay)
Copy-Item (Join-Path $overlay 'src\lib\hustle-phase2\server.ts') (Join-Path $Worktree 'src\lib\hustle-phase2\server.ts')
Copy-Item (Join-Path $overlay 'src\lib\hustle-phase2\pages.ts') (Join-Path $Worktree 'src\lib\hustle-phase2\pages.ts')
Run-Checked 'git' @('-C',$Worktree,'diff','--check')
Run-Checked 'git' @('-C',$Worktree,'diff','--stat')
Write-Output 'Prepared isolated TWO-MODULE test checkout only. No SQL, settings, Git push or deployment executed.'
Write-Output 'Continue with DESKTOP-NEXT.md using authenticated staging/Vercel tools. Never run the disposable local foundation against hosted staging.'
