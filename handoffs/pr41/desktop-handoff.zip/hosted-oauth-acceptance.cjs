// Opt-in, owned synthetic accounts/roster only. Manual external provider login.
// No token/session/PII reports, traces, screenshots or saved browser storage.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {createRequire}=require('node:module'),{createInterface}=require('node:readline/promises');
const {target}=require('./prepare-test-artifact.cjs');
const BASE='/partners/hustle-carnival/phase-2',API='/api/partners/hustle-carnival/phase-2';
function config(input){
  target(input);
  for(const k of ['authorized','syntheticOnly','keyProjectAlignmentVerified','zeroAdditionalCostVerified'])assert.equal(input[k],true,'Target attestation missing');
  assert(['google','github'].includes(input.provider));assert(['leader','member','outsider'].includes(input.role));
  assert(['before','open','closed'].includes(input.window));
  if(input.window==='open')assert.equal(input.isolatedClockFixtureApproved,true,'Current-date open tests require approved isolated clock fixture');
  if(input.role==='leader')assert.equal(input.expectPartial,true,'Use a fresh pair with member pending');
  if(input.role!=='outsider')assert(/^[a-f0-9]{64}$/.test(input.leaderHash||''));
  return input;
}
function checkKey(key,ref){
  assert(key&&key.trim());
  if(key.split('.').length===3){const c=JSON.parse(Buffer.from(key.split('.')[1],'base64url').toString());assert.equal(c.ref,ref,'Wrong-project key');}
  // New opaque keys require prior dashboard alignment attestation; cannot decode them.
}
async function main(){
  if(process.argv[2]!=='--authorized'||!process.argv[3])throw Error('Explicit authorization and private scenario config required');
  const c=config(JSON.parse(fs.readFileSync(process.argv[3],'utf8')));
  const project='https://'+c.projectRef+'.supabase.co',repo=process.env.PR41_REPO||'/workspace/work/audit-pr41';
  const requireRepo=createRequire(path.join(repo,'package.json'));
  let chromium;try{({chromium}=requireRepo('@playwright/test'))}catch{({chromium}=requireRepo('playwright'))}
  const {createServerClient}=requireRepo('@supabase/ssr');
  const anon=process.env.PR41_TEST_ANON_KEY;checkKey(anon,c.projectRef);
  const service=process.env.PR41_TEST_SERVICE_KEY;if(service)checkKey(service,c.projectRef);
  const rl=createInterface({input:process.stdin,output:process.stdout});let browser;
  try{
    browser=await chromium.launch({headless:false,...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH}:{})});
    const ctx=await browser.newContext({serviceWorkers:'block'});let wrongBackend=false;
    await ctx.route('**/*',r=>{
      const u=new URL(r.request().url());
      if((u.hostname.endsWith('.supabase.co')&&u.origin!==project)||['hackermate.in','www.hackermate.in'].includes(u.hostname)){wrongBackend=true;return r.abort();}
      return r.continue();
    });
    const page=await ctx.newPage();
    if(c.invitationUrl){
      const invite=new URL(c.invitationUrl);assert.equal(invite.origin,c.origin);assert.equal(invite.pathname,BASE+'/invite');
      assert(/^#[A-Za-z0-9_-]{43}$/.test(invite.hash));
      assert.equal(crypto.createHash('sha256').update(invite.hash.slice(1)).digest('hex'),c.leaderHash);
      await page.goto(invite.href);await page.getByRole('button',{name:'Continue securely',exact:true}).click();
      await page.waitForURL(c.origin+BASE);assert.equal(new URL(page.url()).hash,'');
      const cookie=(await ctx.cookies()).find(x=>x.name==='hm_hustle_p2_account');
      assert(cookie&&cookie.httpOnly&&cookie.secure&&cookie.sameSite==='Lax'&&cookie.path==='/');
    }else await page.goto(c.origin+BASE);
    const login=page.getByRole('link',{name:'Sign up / Sign in with HackerMate',exact:true});
    await login.click();await page.getByRole('checkbox').check();
    let visitedProvider=false;
    page.on('request',r=>{const u=new URL(r.url());if(c.provider==='google'?u.hostname==='accounts.google.com':u.hostname==='github.com'&&u.pathname.startsWith('/login'))visitedProvider=true});
    await page.getByRole('button',{name:c.provider==='google'?'Continue with Google':'Continue with GitHub',exact:true}).click();
    await rl.question('Use only the approved tester account. Finish provider login/onboarding and return to Round 2; press Enter here. ');
    assert(visitedProvider,'No actual selected-provider navigation observed');assert.equal(new URL(page.url()).origin,c.origin);assert.equal(new URL(page.url()).pathname,BASE);
    assert.equal(wrongBackend,false,'Production or wrong Supabase project contacted');
    const cookies=await ctx.cookies();
    const client=createServerClient(project,anon,{cookies:{getAll:()=>cookies.map(x=>({name:x.name,value:x.value})),setAll(){throw Error('Session requires browser refresh before capture')}}});
    const session=await client.auth.getSession();assert(!session.error&&session.data.session,'No real SSR session');
    const token=session.data.session.access_token;
    const rpc=async(name,args={},credential=token)=>{
      const r=await fetch(project+'/rest/v1/rpc/'+name,{method:'POST',redirect:'error',headers:{apikey:credential===service?service:anon,Authorization:'Bearer '+credential,'Content-Type':'application/json'},body:JSON.stringify(args),signal:AbortSignal.timeout(20000)});
      const data=await r.json();return {status:r.status,data};
    };
    const claimed=await rpc('hustle_phase2_claim');
    if(c.role==='outsider')assert.equal(claimed.status,403);
    else{
      assert.equal(claimed.status,200);assert.equal(claimed.data.role,c.role);
      if(c.role==='leader')assert.equal(claimed.data.fully_onboarded,false,'Member already bound; use fresh pair');
      if(c.role==='member'){assert.equal(claimed.data.fully_onboarded,true);if(c.expectedDecision)assert.equal(claimed.data.decision,c.expectedDecision);}
      const response=await rpc('hustle_phase2_respond',{p_hash:c.leaderHash,p_decision:c.decision||'confirmed'});
      if(c.role==='member')assert.equal(response.status,403);
      else if(c.window==='open'){assert.equal(response.status,200);assert.equal(response.data.status,'ok');}
      else{assert.equal(response.status,200);assert(['closed','invalid'].includes(response.data.status));}
      // Browser route shares the authenticated context; member cannot use leader context.
      if(c.role==='member'){
        const staged=await ctx.request.post(c.origin+API+'/respond',{headers:{Origin:c.origin},data:{decision:'confirmed'}});
        assert([403,404].includes(staged.status()));
      }
    }
    for(const credential of [anon,...(service?[service]:[])]){
      const denied=await rpc('hustle_phase2_respond',{p_hash:c.leaderHash||'a'.repeat(64),p_decision:'confirmed'},credential);
      assert([401,403,404].includes(denied.status),'Legacy authority unexpectedly available');
    }
    console.log('PASS: selected-provider return, SSR session, target isolation, role/binding and direct-RPC checks. Complete browser-attendance/session-revocation cases in RUNBOOK before sign-off.');
    await ctx.close();
  }finally{rl.close();if(browser)await browser.close();}
}
module.exports={config,checkKey};
if(require.main===module)main().catch(()=>{console.error('Acceptance stopped. No private exception/session details printed; inspect the approved test browser privately.');process.exitCode=1});
