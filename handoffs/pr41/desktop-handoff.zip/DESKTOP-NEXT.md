NEXT ACTION — Desktop Codex, Windows

Authorization already granted in chat: staging containment verification, synthetic Hustle prerequisites/fixtures, branch-specific Preview configuration, two-module test-overlay deployment and controlled Google/GitHub acceptance. Do NOT ask again. Scope is only Supabase qusshzpkvwzfhdcmsosp and the named Preview; production rhryjrbebfrrfhtyyzbs is excluded. Existing accounts/teams must stay untouched. No real recipients, production enablement or paid resource.

Owner-completed facts (accept; do not repeat console checks): custom SMTP disabled, no Auth hooks, two Google accounts controlled by owner, five example.com demos, five QA teams. Default Auth mail remains possible: use only explicitly controlled tester addresses; never send auth mail to example.com demos.

Cloud execution status: no Supabase/Vercel authenticated tools/identity, no CLIs; worker still excludes staging/Preview hosts. This is a concrete access blocker, not a failing application or browser test. Desktop must use its existing authenticated connectors/CLI/browser; do not recreate resources or request the granted scope again.

1. Unzip this packet to a private directory. Prepare a separate local test checkout (no push/automatic Preview side effect):

    powershell -NoProfile -File .\desktop-prepare.ps1 -Repo 'C:\PATH\HackerMate_Backup' -Worktree 'C:\PATH\HackerMate_Hustle_OAuth'

The merge must already exist locally. If missing, Desktop may fetch that exact merge from the existing origin, then rerun. Generator canonicalizes Windows CRLF before frozen-source hashes. It changes only server.ts and pages.ts; no source gate flip, migrations or main-branch changes.

2. Verify the selected authenticated Supabase connection is qusshzpkvwzfhdcmsosp. Execute staging-containment-readonly.sql there (or its queries with the authenticated connector). Both missing-destination/secret booleans and empty HTTP queue must be freshly established. Privately inspect the installed notification function to confirm it returns before net.http_post when config is absent; a fingerprint alone is insufficient. Review any other outbound triggers/functions reachable by signup/profile/fixture actions. Do not print secrets or queue bodies. Stop on active real-recipient effects; do not guess containment from old observations.

3. From that staging catalog, install ONLY missing compatible Hustle prerequisites as separately scoped STAGING transactions using canonical reviewed sources; never full-directory db push. Files to assess: 202610060002_partner_organizer_access.sql, 20261018082156_hustle_phase2_shortlist.sql, 20261018174144_hustle_round2_auth_guards.sql, 20261020055415_hustle_participant_accounts.sql. Existing installations are not rerun. Confirm the fixed Hustle event exists or create the approved synthetic event using the actual schema. Preserve existing accounts, roles and teams. Preserve historical migration source bytes and use the actual staging ledger procedure. The first foundation may already exist; the auth-guards file affects is_admin, so review actual staging dependencies before applying. Missing owner/Auth privileges are STOP/reconcile conditions, never browser/service grants. No production r7 envelope here.

Do NOT run scripts/fixtures/hustle-auth-foundation.sql or repoint the disposable integration runner to staging: they create substitute schema/roles and manipulate accounts. Build the minimal hosted fixture against actual staging schema, not the local stand-in schema. Pre-existing Phase2 roster/bindings require preservation and a collision-free test plan; never clear them to satisfy the migration guard.

4. Use only new, controlled Google/GitHub tester identities; do not modify existing seven Auth users. Create fresh synthetic pair(s) with those exact emails and namespaced team IDs through the approved import contract, inactive then activated separately for tests. No app role broadening on existing users: if an issuer/admin is needed, provision only a NEW controlled test operator with a recorded fixture ID. Generate only synthetic invitations; deliver no messages. Keep all fixture identifiers and cleanup scope private and explicit.

5. Vercel authenticated tools: select hacker-mate-backup and PREVIEW BRANCH ONLY feat/hustle-round2-account-onboarding. Set the six nonsecret values from staging-preview-overlay/preview.env.example plus only qusshzpkvwzfhdcmsosp anon/service keys via secure input. Never copy/export production values; never set Production or shared/all-environment scope. Remove/override any test deployment outbound production integration only in this approved test scope. Keep billing within existing allowance; no new project/branching add-on/seat/trial.

Deploy the separate test checkout as PREVIEW, never --prod and never merge to main. Use Desktop's authenticated Vercel connector or installed CLI after checking its --help for branch selection; ensure branch overrides are used. Verify resulting deployment Environment=Preview, exact request/callback origin and both build-time frontend and runtime server staging alignment. The overlay allowlists the named stable branch alias, so test that alias, not a different immutable deployment URL. Preserve production variables and deployment. If the branch alias differs, regenerate only the offline exact-origin overlay before deployment.

6. Google/GitHub test providers: if already configured compatibly, reuse. If manual owner-console work is needed, ONLY these actions require Yash:
   - Google Auth Platform: a TEST client, callback https://qusshzpkvwzfhdcmsosp.supabase.co/auth/v1/callback, correct consent/testing audience and controlled test-user addresses. No production client edits.
   - GitHub Developer settings -> OAuth Apps: dedicated TEST app with that same staging callback; authorized controlled GitHub account with a verified matching email.
   - Supply TEST secrets directly into staging Auth Providers if Desktop cannot access that secure setting; never paste secrets in chat. Staging Site URL=the approved Preview origin; application /auth/callback allowlisted narrowly. Provider app verification/consent/MFA is completed by the owner, not bypassed.

7. Hosted runner on Windows with a local interactive Chromium/Edge. In PowerShell set PR41_REPO to the separate test checkout, PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH to an existing msedge.exe/chrome.exe, and TEST key variables only via secure local input. Do not echo values. Install only the existing lockfile dependencies if needed, no upgrades.

    $env:PR41_REPO = 'C:\PATH\HackerMate_Hustle_OAuth'
    $env:PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
    node .\hosted-oauth-acceptance.cjs --authorized 'C:\PRIVATE\google-leader.json'

Private scenario JSON uses scenario.example.json's fields but the approved target, all attestations supported by evidence, a NEW synthetic leader invitation/hash and provider. Reuse no real invitation. Run both providers with appropriate fresh fixtures. Runner allows manual provider login and claims/responds only on staging. It reports no tokens or PII. Also execute the manual browser button/session/recovery/concurrency cases in RUNBOOK; this runner alone is not full acceptance.

Attendance SUCCESS tonight requires a separate disposable STAGING-ONLY clock fixture; it is within the authorized synthetic testing scope. Follow the existing disposable test-clock approach, preserve original definitions/hashes privately and restore them after testing. Never edit frozen migration files or production definitions. Without the fixture, mark before-window denial PASS and successful attendance NOT TESTED, never PASS. Exact Oct23 real-clock window remains unchanged in production.

8. Report exact HTTP and assertion outcomes (Google/GitHub return, SSR refresh, leader/member/outsider routes and direct RPC, revocation, invitation recovery, legacy denial, independent member onboarding). Include deployment ID/source/target, redacted fixture counts and containment/queue result before and after. No traces/screenshots/logged secrets or real-user data. Cleanup only newly recorded synthetic fixture IDs using a reviewed FK-safe plan; never reset existing tables/users or remove production data.

No live result is claimed by the Cloud packet. Desktop continues from step 2 using its authenticated staging connection; steps 3–8 are already authorized and should proceed when their concrete checks pass.
