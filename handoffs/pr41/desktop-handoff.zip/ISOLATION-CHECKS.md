Named staging target — read-only verification only

Supabase project: hackermate-staging-motion / qusshzpkvwzfhdcmsosp.
Frontend: https://hacker-mate-backup-git-feat-hustl-8bf9d7-yashshah1211s-projects.vercel.app
Production excluded: rhryjrbebfrrfhtyyzbs and hackermate.in/www.hackermate.in.
Owner-reported existing state: 7 Auth users, 7 profiles, 5 teams and other records. No raw record values were inspected here. Counts/name/physical separation do not prove test safety.

Completed offline: exact two-module overlay generated in staging-preview-overlay/, with source/output hashes and false authorization attestations. No SQL or account changes. Production source gate remains false. This overlay is not deployed. Existing Preview therefore cannot yet exercise its test gate.

Minimum isolation evidence before setup approval

1. Existing records: an authorized owner classifies the 7 identities/profiles and existing teams/other data as owned test records or real/unrelated data. Return a classification and preservation decision, not names/emails or a user export. Do not delete, reset or modify them. If real/unowned data is present and cannot be safely isolated, reject this project for hosted acceptance; do not call it synthetic-only.
2. Fixed-event collision: independently verify whether the test project already contains Hustle event UUID 0da43cba-90dc-449c-a126-a2fc8be8a379, Phase2 tables, roster/batches and event-organizer assignments. All Phase2 functions use that fixed event. Confirm approved test scope and collision-free fresh fixture IDs/digests. Do not improvise an event-ID rewrite to run alongside unknown records. Unknown definitions/prerequisites need separately approved compatible setup. No production schema/data copy. No database query was run by this task.
3. Outbound and shared infrastructure: stage Auth SMTP/hooks, database webhooks/triggers/functions, scheduled jobs, Edge Functions, Storage integrations and app email/Discord/Sentry/replay services must be inventoried read-only. Confirm future test signup/profile/claim actions cannot notify real recipients or invoke production services. Any required disabling/change needs setup approval; inspecting is not permission to change it.
4. Key/project alignment: privately compare Vercel Preview branch-specific frontend URL/anon key and server service key with staging project's API Keys/Connect. No shared/Production scope changes. Opaque keys require dashboard matching; matching a hostname or decoding an old JWT key alone does not prove all credentials align. Verify actual browser Auth/Data API origin only after hosted execution is approved. Until then configuration evidence is provisional.
5. Provider readiness: stage Auth provider configuration and URL settings; Google test client/audience/test-user eligibility; dedicated GitHub OAuth app/callback. Inspect only. Stage provider callback must be https://qusshzpkvwzfhdcmsosp.supabase.co/auth/v1/callback. App Site URL must be the exact frontend origin; application callback is /auth/callback. No production clients/secrets/callbacks changed. Redacted readiness results, never secret values.
6. Cost and access: existing Supabase organization plan/usage and Vercel plan/usage/eligibility; confirm no new billable project/branch/seat/add-on and no trial/upgrade. Confirm operator can deploy the dedicated Preview, configure only test scopes and clean up only new owned fixtures. No zero-cost assertion until verified.

Exact read-only console pages

- https://supabase.com/dashboard/project/qusshzpkvwzfhdcmsosp/settings/general — project identity/owner.
- Project Settings -> API Keys / Connect — privately compare credentials/URL; do not export secrets.
- Authentication -> Users — owner classification of existing accounts only, no changes/export.
- Authentication -> Sign In / Providers; URL Configuration; Email/SMTP and Hooks — readiness and outbound dependencies.
- Project Database/Webhooks, Edge Functions and scheduled integrations — read-only inventory of effects, no SQL executed here.
- Supabase organization Billing/Usage — quota and incremental cost.
- https://vercel.com/yashshah1211s-projects/hacker-mate-backup/settings/environment-variables — Preview branch overrides for feat/hustle-round2-account-onboarding, secret presence/alignment only.
- Preview deployment details — Source SHA, HTTPS hostname, Preview environment and deployed build configuration.
- Vercel team Settings -> Billing/Usage — current allowances and hosting eligibility.

Access state

This session has no authenticated Supabase/Vercel connector, attached account identity or configured account credential. Public dashboard tooling did not expose authenticated settings. Read-only authorization exists, but technical account access does not. Owner-provided redacted dashboard evidence or an authenticated read-only connection is needed; do not paste tokens/keys.

Current worker network policy also lacks hackermate.in/www.hackermate.in, the named Preview hostname and qusshzpkvwzfhdcmsosp.supabase.co. Production retry on www got proxy CONNECT 403 with zero application HTTP responses. Environment status and /etc/codex/network-policy.json agree. Apply the saved policy to this worker if supported; otherwise start a fresh task bound to the updated environment. Saving did not hot-update this worker. Do not bypass the proxy. For future authorized hosted testing also allow the exact staging/Preview/provider hosts through the supported configuration workflow.

One scoped approval AFTER all six evidence gates pass — prepared, not requested yet

Authorize only the named staging project and Preview branch, approved controlled tester identities, fresh namespaced synthetic fixtures and the reviewed two-module overlay. Cover required test-only provider/URL configuration, approved schema prerequisites and isolated test-clock fixture, Preview-only environment keys/flags, one test deployment, Google/GitHub acceptance and cleanup of only newly created fixture IDs. Preserve all existing records; no production settings/keys/data/accounts, notifications, paid resources, migration changes or production enablement. Record exact target, artifact hashes, operators, fixture IDs, cleanup method and expiration. If a required destructive reconciliation or cost is discovered, STOP; this scope does not cover it.

The real time is before Oct23. Successful attendance today requires the separately approved isolated test-clock fixture; without it, record before-window denial as passed and open-window attendance as untested. Do not alter frozen production SQL or the real deadline.
